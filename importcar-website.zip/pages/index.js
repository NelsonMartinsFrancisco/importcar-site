
import Head from 'next/head';

export default function Home() {
  return (
    <div style={{ padding: '2rem' }}>
      <Head>
        <title>ImportCar.pt</title>
      </Head>
      <h1>ImportCar.pt</h1>
      <p>
        Encontre o seu carro ideal importado da Bélgica com confiança,
        verificação mecânica e entrega em Portugal. Pode também pedir
        financiamento diretamente pelo site.
      </p>
    </div>
  );
}
